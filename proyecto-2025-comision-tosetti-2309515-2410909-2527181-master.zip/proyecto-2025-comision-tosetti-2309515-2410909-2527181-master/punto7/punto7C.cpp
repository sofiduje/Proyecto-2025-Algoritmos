// COMPARACIÓN ENTRE 2 PAISES: MONTO TOTAL DE VENTAS, PRODUCTO MÁS VENDIDO, MEDIO DE ENVÍO MÁS USADO

#include <iostream>
#include <fstream>
#include <sstream>
#include <unordered_map>
#include <string>
#include <vector>
#include <limits>

using namespace std;

// Estructuras globales
unordered_map<string, double> ventas_por_pais;
unordered_map<string, unordered_map<string, int>> cantidad_producto_por_pais;
unordered_map<string, unordered_map<string, int>> envios_por_pais;

// Función para separar una línea CSV
vector<string> splitCSVLine(const string& linea) {
    vector<string> valores;
    stringstream ss(linea);
    string valor;

    while (getline(ss, valor, ',')) {
        valores.push_back(valor);
    }

    return valores;
}

// Procesar archivo CSV
void procesarArchivoCSV(const string& nombreArchivo) {
    ifstream archivo(nombreArchivo);
    if (!archivo.is_open()) {
        cout << "Error al abrir el archivo." << endl;
        return;
    }

    string linea;
    getline(archivo, linea); // Saltar encabezado

    while (getline(archivo, linea)) {
        vector<string> datos = splitCSVLine(linea);
        if (datos.size() < 11) continue;

        string pais = datos[2];
        string producto = datos[5];
        string medioEnvio = datos[10];

        int cantidad = stoi(datos[7]);
        double monto = stod(datos[9]);

        ventas_por_pais[pais] += monto;
        cantidad_producto_por_pais[pais][producto] += cantidad;
        envios_por_pais[pais][medioEnvio]++;
    }

    archivo.close();
}

// Mostrar comparación de monto total entre dos países
void compararMontoTotalVentas(string pais1, string pais2) {
    if (ventas_por_pais.count(pais1) && ventas_por_pais.count(pais2)) {
        cout << pais1 << ": $" << ventas_por_pais[pais1] << endl;
        cout << pais2 << ": $" << ventas_por_pais[pais2] << endl;

    } else {
        cout << "Uno o ambos paises no se encuentran en la base de datos." << endl;
    }
}

// Obtener producto más vendido en unidades por país
string productoMasVendido(string pais) {
    string productoMax = "";
    int maxCantidad = 0;

    for (auto& par : cantidad_producto_por_pais[pais]) {
        if (par.second > maxCantidad) {
            maxCantidad = par.second;
            productoMax = par.first;
        }
    }

    return productoMax;
}

// Obtener medio de envío más usado por país
string medioEnvioMasUsado(string pais) {
    string medioMax = "";
    int maxCantidad = 0;

    for (auto& par : envios_por_pais[pais]) {
        if (par.second > maxCantidad) {
            maxCantidad = par.second;
            medioMax = par.first;
        }
    }

    return medioMax;
}

//Verificar si los países existen en la base de datos
bool paisExiste(const string& pais) {
    return ventas_por_pais.find(pais) != ventas_por_pais.end();
}

// Menú de prueba
int main() {
    procesarArchivoCSV("ventas_sudamerica(1).csv");

    string pais1, pais2;

    cout << "=== COMPARACION ENTRE DOS PAISES ===" << endl;

    do {
        cout << "Ingrese el primer pais: ";
        getline(cin, pais1);
        if (!paisExiste(pais1)) {
            cout << "Pais no encontrado. Intente nuevamente.\n";
        }
    } while (!paisExiste(pais1));

    do {
        cout << "Ingrese el segundo pais: ";
        getline(cin, pais2);
        if (!paisExiste(pais2)) {
            cout << "Pais no encontrado. Intente nuevamente.\n";
        }
    } while (!paisExiste(pais2));

    cout << "\n--- Monto total de ventas ---" << endl;
    compararMontoTotalVentas(pais1, pais2);

    cout << "\n--- Producto mas vendido ---" << endl;
    cout << pais1 << ": " << productoMasVendido(pais1) << endl;
    cout << pais2 << ": " << productoMasVendido(pais2) << endl;

    cout << "\n--- Medio de envio mas usado ---" << endl;
    cout << pais1 << ": " << medioEnvioMasUsado(pais1) << endl;
    cout << pais2 << ": " << medioEnvioMasUsado(pais2) << endl;

    return 0;
}


