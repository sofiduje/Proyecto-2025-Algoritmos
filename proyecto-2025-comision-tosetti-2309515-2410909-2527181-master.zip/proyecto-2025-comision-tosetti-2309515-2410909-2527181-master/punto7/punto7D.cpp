//COMPARACIÓN ENTRE DOS PRODUCTOS DISCRIMINADO POR TODOS LOS PAÍSES

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <unordered_map>

using namespace std;

unordered_map<string, unordered_map<string, pair<int, double>>> productoPaisDatos;

void procesarArchivoCSV(const string& nombreArchivo) {
    ifstream archivo(nombreArchivo);
    string linea;
    getline(archivo, linea); // saltar encabezado

    while (getline(archivo, linea)) {
        stringstream ss(linea);
        string idVenta, fecha, pais, ciudad, cliente, producto, categoria, cantidadStr, precioStr, montoStr, medioEnvio, estadoEnvio;

        getline(ss, idVenta, ',');
        getline(ss, fecha, ',');
        getline(ss, pais, ',');
        getline(ss, ciudad, ',');
        getline(ss, cliente, ',');
        getline(ss, producto, ',');
        getline(ss, categoria, ',');
        getline(ss, cantidadStr, ',');
        getline(ss, precioStr, ',');
        getline(ss, montoStr, ',');
        getline(ss, medioEnvio, ',');
        getline(ss, estadoEnvio, ',');

        int cantidad = stoi(cantidadStr);
        double monto = stod(montoStr);

        productoPaisDatos[producto][pais].first += cantidad;
        productoPaisDatos[producto][pais].second += monto;
    }

    archivo.close();
}

void compararProductosPorPais(const string& producto1, const string& producto2) {
    cout << "\nComparacion de productos: " << producto1 << " vs " << producto2 << "\n\n";

    unordered_map<string, pair<int, double>> datos1 = productoPaisDatos[producto1];
    unordered_map<string, pair<int, double>> datos2 = productoPaisDatos[producto2];

    // Unión de países presentes en ambos productos
    unordered_map<string, bool> paises;
    for (const auto& p : datos1) paises[p.first] = true;
    for (const auto& p : datos2) paises[p.first] = true;

    for (const auto& entry : paises) {
        string pais = entry.first;
        int cant1 = datos1.count(pais) ? datos1[pais].first : 0;
        double monto1 = datos1.count(pais) ? datos1[pais].second : 0.0;

        int cant2 = datos2.count(pais) ? datos2[pais].first : 0;
        double monto2 = datos2.count(pais) ? datos2[pais].second : 0.0;

        cout << "Pais: " << pais << "\n";
        cout << "  " << producto1 << " - Cantidad: " << cant1 << ", Monto: $" << monto1 << "\n";
        cout << "  " << producto2 << " - Cantidad: " << cant2 << ", Monto: $" << monto2 << "\n\n";
    }
}

int main() {
    procesarArchivoCSV("ventas_sudamerica(1).csv");

    string producto1, producto2;

    // Validar producto 1
    while (true) {
        cout << "Ingrese el primer producto a comparar: ";
        getline(cin, producto1);

        if (productoPaisDatos.count(producto1) > 0) break;

        cout << "Producto '" << producto1 << "' no encontrado.\n";
        cout << "Productos disponibles:\n";
        for (const auto& p : productoPaisDatos) {
            cout << " - " << p.first << "\n";
        }
    }

    // Validar producto 2
    while (true) {
        cout << "Ingrese el segundo producto a comparar: ";
        getline(cin, producto2);

        if (productoPaisDatos.count(producto2) > 0) break;

        cout << "Producto '" << producto2 << "' no encontrado.\n";
        cout << "Productos disponibles:\n";
        for (const auto& p : productoPaisDatos) {
            cout << " - " << p.first << "\n";
        }
    }

    compararProductosPorPais(producto1, producto2);

    return 0;
}

