//  LISTADO DE VENTAS REALIZADAS EN UNA CIUDAD ESPECÍFICA

#include <iostream>
#include <fstream>
#include <sstream>
#include <unordered_map>
#include <vector>
#include <algorithm> 
using namespace std;

// Estructura principal para almacenar una venta
struct Venta {
    string idVenta, fecha, pais, ciudad, cliente, producto, categoria, medioEnvio, estadoEnvio;
    int cantidad;
    double precioUnitario, montoTotal;
};

// Tabla hash principal: País → Ciudad → Lista de Ventas
unordered_map<string, unordered_map<string, vector<Venta>>> ventasPorUbicacion;

// Función para cargar el archivo CSV en la estructura
void cargarVentasDesdeCSV(const string& nombreArchivo) {
    ifstream archivo(nombreArchivo);
    string linea;
    getline(archivo, linea); // Saltea encabezado

    while (getline(archivo, linea)) {
        stringstream ss(linea);
        string campo;
        Venta venta;

        getline(ss, venta.idVenta, ',');
        getline(ss, venta.fecha, ',');
        getline(ss, venta.pais, ',');
        getline(ss, venta.ciudad, ',');
        getline(ss, venta.cliente, ',');
        getline(ss, venta.producto, ',');
        getline(ss, venta.categoria, ',');
        getline(ss, campo, ',');
        venta.cantidad = stoi(campo);
        getline(ss, campo, ',');
        venta.precioUnitario = stod(campo);
        getline(ss, campo, ',');
        venta.montoTotal = stod(campo);
        getline(ss, venta.medioEnvio, ',');
        getline(ss, venta.estadoEnvio, ',');

        ventasPorUbicacion[venta.pais][venta.ciudad].push_back(venta);
    }

    archivo.close();
}

// Quicksort para ordenar un vector de ventas por nombre de producto
void quicksort(vector<Venta>& ventas, int inicio, int fin) {
    if (inicio >= fin) return;

    string pivote = ventas[fin].producto;
    int i = inicio - 1;

    for (int j = inicio; j < fin; j++) {
        if (ventas[j].producto < pivote) {
            i++;
            swap(ventas[i], ventas[j]);
        }
    }

    swap(ventas[i + 1], ventas[fin]);
    int indicePivote = i + 1;

    quicksort(ventas, inicio, indicePivote - 1);
    quicksort(ventas, indicePivote + 1, fin);
}

// Mostrar las ventas realizadas en una ciudad específica
void mostrarVentasDeCiudad() {
    string ciudadBuscada;
    bool encontrada = false;

    while (!encontrada) {
        cout << "Ingrese el nombre de la ciudad: ";
        getline(cin >> ws, ciudadBuscada); // El ws evita errores con espacios

        for (const auto& parPais : ventasPorUbicacion) {
            const string& pais = parPais.first;
            const auto& mapaCiudades = parPais.second;

            auto itCiudad = mapaCiudades.find(ciudadBuscada);
            if (itCiudad != mapaCiudades.end()) {
                vector<Venta> ventas = itCiudad->second;

                if (!ventas.empty()) {
                    quicksort(ventas, 0, ventas.size() - 1);
                }

                cout << "\nVentas en " << ciudadBuscada << " (" << pais << "):\n";
                for (const Venta& v : ventas) {
                    cout << "ID: " << v.idVenta
                         << " | Producto: " << v.producto
                         << " | Categoria: " << v.categoria
                         << " | Cliente: " << v.cliente
                         << " | Cantidad: " << v.cantidad
                         << " | Monto: $" << v.montoTotal
                         << " | Fecha: " << v.fecha
                         << " | Medio: " << v.medioEnvio
                         << " | Estado: " << v.estadoEnvio << '\n';
                }

                encontrada = true;
                break; // Sale del for cuando la ciudad se encuentra
            }
        }

        if (!encontrada) {
            cout << "Ciudad invalida. Intente nuevamente.\n";
        }
    }
}

// Función principal
int main() {
    cargarVentasDesdeCSV("ventas_sudamerica(1).csv");
    mostrarVentasDeCiudad();
    return 0;
}