#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>
#include <algorithm>
#include <cctype>

using namespace std;

// === Estructuras ===

struct Venta {
    string idVenta, fecha, pais, ciudad, cliente, producto, categoria, medioEnvio, estadoEnvio;
    int cantidad;
    double precioUnitario, montoTotal;
};

struct NodoAVL {
    string fecha;  // AAAA-MM-DD
    vector<Venta> ventas;
    NodoAVL* izq;
    NodoAVL* der;
    int altura;
};

// === Variables globales ===

unordered_map<string, unordered_map<string, vector<Venta>>> ventasPorUbicacion;
unordered_map<string, NodoAVL*> ventasPorPais;

// === Declaración de funciones utilizadas en cargarCSV ===

string convertirFechaOrdenable(const string& fechaOriginal);
NodoAVL* insertarAVL(NodoAVL* nodo, const string& fecha, const Venta& venta);

// === Funciones AVL ===

int altura(NodoAVL* nodo) {
    return nodo ? nodo->altura : 0;
}

int balance(NodoAVL* nodo) {
    return nodo ? altura(nodo->izq) - altura(nodo->der) : 0;
}

void actualizarAltura(NodoAVL* nodo) {
    if (nodo)
        nodo->altura = 1 + max(altura(nodo->izq), altura(nodo->der));
}

NodoAVL* rotarDerecha(NodoAVL* y) {
    NodoAVL* x = y->izq;
    NodoAVL* T2 = x->der;
    x->der = y;
    y->izq = T2;
    actualizarAltura(y);
    actualizarAltura(x);
    return x;
}

NodoAVL* rotarIzquierda(NodoAVL* x) {
    NodoAVL* y = x->der;
    NodoAVL* T2 = y->izq;
    y->izq = x;
    x->der = T2;
    actualizarAltura(x);
    actualizarAltura(y);
    return y;
}

NodoAVL* insertarAVL(NodoAVL* nodo, const string& fecha, const Venta& venta) {
    if (!nodo) return new NodoAVL{fecha, {venta}, nullptr, nullptr, 1};

    if (fecha < nodo->fecha)
        nodo->izq = insertarAVL(nodo->izq, fecha, venta);
    else if (fecha > nodo->fecha)
        nodo->der = insertarAVL(nodo->der, fecha, venta);
    else {
        nodo->ventas.push_back(venta);
        return nodo;
    }

    actualizarAltura(nodo);
    int balanceFactor = balance(nodo);

    if (balanceFactor > 1 && fecha < nodo->izq->fecha)
        return rotarDerecha(nodo);
    if (balanceFactor < -1 && fecha > nodo->der->fecha)
        return rotarIzquierda(nodo);
    if (balanceFactor > 1 && fecha > nodo->izq->fecha) {
        nodo->izq = rotarIzquierda(nodo->izq);
        return rotarDerecha(nodo);
    }
    if (balanceFactor < -1 && fecha < nodo->der->fecha) {
        nodo->der = rotarDerecha(nodo->der);
        return rotarIzquierda(nodo);
    }

    return nodo;
}

// === Funciones auxiliares ===

// Convierte fecha de DD-MM-AAAA a AAAA-MM-DD para ordenamiento lexicográfico
string convertirFechaOrdenable(const string& fechaOriginal) {
    string dia = fechaOriginal.substr(0, 2);
    string mes = fechaOriginal.substr(3, 2);
    string anio = fechaOriginal.substr(6, 4);
    return anio + "-" + mes + "-" + dia;
}

// Valida formato de fecha DD-MM-AAAA
bool fechaValida(const string& fecha) {
    if (fecha.length() != 10) return false;
    if (fecha[2] != '-' || fecha[5] != '-') return false;

    for (int i = 0; i < (int)fecha.length(); ++i) {
        if (i == 2 || i == 5) continue;
        if (!isdigit(fecha[i])) return false;
    }

    int dia = stoi(fecha.substr(0, 2));
    int mes = stoi(fecha.substr(3, 2));
    int anio = stoi(fecha.substr(6, 4));

    if (dia < 1 || dia > 31 || mes < 1 || mes > 12 || anio < 1900 || anio > 2100)
        return false;

    return true;
}

// === Función cargarCSV ===

void cargarCSV(const string& nombreArchivo) {
    ifstream archivo(nombreArchivo);
    if (!archivo.is_open()) {
        cerr << "No se pudo abrir el archivo: " << nombreArchivo << endl;
        return;
    }

    string linea;
    getline(archivo, linea); // Saltear encabezado

    while (getline(archivo, linea)) {
        stringstream ss(linea);
        string campo;
        Venta v;

        getline(ss, v.idVenta, ',');
        getline(ss, campo, ','); v.fecha = convertirFechaOrdenable(campo);
        getline(ss, v.pais, ',');
        getline(ss, v.ciudad, ',');
        getline(ss, v.cliente, ',');
        getline(ss, v.producto, ',');
        getline(ss, v.categoria, ',');
        getline(ss, campo, ','); v.cantidad = stoi(campo);
        getline(ss, campo, ','); v.precioUnitario = stod(campo);
        getline(ss, campo, ','); v.montoTotal = stod(campo);
        getline(ss, v.medioEnvio, ',');
        getline(ss, v.estadoEnvio, ',');

        // Guardar en mapa por ubicación
        ventasPorUbicacion[v.pais][v.ciudad].push_back(v);

        // Insertar en AVL por país
        ventasPorPais[v.pais] = insertarAVL(ventasPorPais[v.pais], v.fecha, v);
    }

    archivo.close();
}

// === Función para mostrar ventas en una ciudad específica ===
void mostrarVentasDeCiudad() {
    string ciudadBuscada;
    bool encontrada = false;

    while (!encontrada) {
        cout << "Ingrese el nombre de la ciudad: ";
        getline(cin >> ws, ciudadBuscada);

        for (const auto& parPais : ventasPorUbicacion) {
            const string& pais = parPais.first;
            const auto& mapaCiudades = parPais.second;

            auto itCiudad = mapaCiudades.find(ciudadBuscada);
            if (itCiudad != mapaCiudades.end()) {
                vector<Venta> ventas = itCiudad->second;
                sort(ventas.begin(), ventas.end(), [](const Venta& a, const Venta& b) {
                    return a.producto < b.producto;
                });

                cout << "\nVentas en " << ciudadBuscada << " (" << pais << "):\n";
                for (const Venta& v : ventas) {
                    cout << "ID: " << v.idVenta
                         << " | Producto: " << v.producto
                         << " | Categoria: " << v.categoria
                         << " | Cliente: " << v.cliente
                         << " | Cantidad: " << v.cantidad
                         << " | Monto: $" << v.montoTotal
                         << " | Fecha: " << v.fecha
                         << " | Medio: " << v.medioEnvio
                         << " | Estado: " << v.estadoEnvio << '\n';
                }

                encontrada = true;
                break;
            }
        }

        if (!encontrada) {
            cout << "Ciudad invalida. Intente nuevamente.\n";
        }
    }
}

// === Función para listar ventas en rango de fechas por país ===
void listarVentasPorRango(NodoAVL* nodo, const string& desde, const string& hasta) {
    if (!nodo) return;
    if (desde < nodo->fecha)
        listarVentasPorRango(nodo->izq, desde, hasta);
    if (desde <= nodo->fecha && nodo->fecha <= hasta) {
        for (const Venta& v : nodo->ventas) {
            cout << "ID: " << v.idVenta 
            << " | Fecha: " << v.fecha
            << " | Producto: " << v.producto 
            << " | Cliente: " << v.cliente
            << " | Monto: $" << v.montoTotal << endl;
        }
    }
    if (hasta > nodo->fecha)
        listarVentasPorRango(nodo->der, desde, hasta);
}

void mostrarVentasPorRangos() {
    string paisUsuario, fechaDesde, fechaHasta;

    cout << "\nIngrese el pais: ";
    getline(cin, paisUsuario);

    while (ventasPorPais.find(paisUsuario) == ventasPorPais.end()) {
        cout << "No hay registros para ese pais. Ingrese nuevamente: ";
        getline(cin, paisUsuario);
    }

    cout << "Ingrese la fecha desde (DD-MM-AAAA): ";
    getline(cin, fechaDesde);
    while (!fechaValida(fechaDesde)) {
        cout << "Fecha invalida. Ingrese nuevamente (DD-MM-AAAA): ";
        getline(cin, fechaDesde);
    }

    cout << "Ingrese la fecha hasta (DD-MM-AAAA): ";
    getline(cin, fechaHasta);
    while (!fechaValida(fechaHasta)) {
        cout << "Fecha invalida. Ingrese nuevamente (DD-MM-AAAA): ";
        getline(cin, fechaHasta);
    }

    string desdeOrdenable = convertirFechaOrdenable(fechaDesde);
    string hastaOrdenable = convertirFechaOrdenable(fechaHasta);

    cout << "\nVentas en " << paisUsuario << " del " << fechaDesde << " al " << fechaHasta << ":\n";
    listarVentasPorRango(ventasPorPais[paisUsuario], desdeOrdenable, hastaOrdenable);
}

// === Main ===
int main() {
    cargarCSV("ventas_sudamerica(1).csv");
    mostrarVentasDeCiudad();
    mostrarVentasPorRangos();
    return 0;
}
