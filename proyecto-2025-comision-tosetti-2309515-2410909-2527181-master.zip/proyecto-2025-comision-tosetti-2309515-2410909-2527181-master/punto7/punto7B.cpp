// LISTADO DE VENTAS REALIZADAS EN UN RANGO DE FECHAS POR PAIS

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;

// Estructura de una venta 
struct Venta {
    string idVenta;
    string fecha; // Formato AAAA-MM-DD
    string ciudad;
    string cliente;
    string producto;
    string categoria;
    int cantidad;
    float precioUnitario;
    float montoTotal;
    string medioEnvio;
    string estadoEnvio;
};

// Conversión de fecha 
string convertirFechaOrdenable(const string& fechaOriginal) {
    string dia = fechaOriginal.substr(0, 2);
    string mes = fechaOriginal.substr(3, 2);
    string anio = fechaOriginal.substr(6, 4);
    return anio + "-" + mes + "-" + dia;
}

// Nodo del AVL
struct NodoAVL {
    string fecha;  // AAAA-MM-DD
    vector<Venta> ventas;
    NodoAVL* izq;
    NodoAVL* der;
    int altura;
};

int altura(NodoAVL* nodo) {
    return nodo ? nodo->altura : 0;
}

int balance(NodoAVL* nodo) {
    return nodo ? altura(nodo->izq) - altura(nodo->der) : 0;
}

void actualizarAltura(NodoAVL* nodo) {
    if (nodo)
        nodo->altura = 1 + max(altura(nodo->izq), altura(nodo->der));
}

NodoAVL* rotarDerecha(NodoAVL* y) {
    NodoAVL* x = y->izq;
    NodoAVL* T2 = x->der;
    x->der = y;
    y->izq = T2;
    actualizarAltura(y);
    actualizarAltura(x);
    return x;
}

NodoAVL* rotarIzquierda(NodoAVL* x) {
    NodoAVL* y = x->der;
    NodoAVL* T2 = y->izq;
    y->izq = x;
    x->der = T2;
    actualizarAltura(x);
    actualizarAltura(y);
    return y;
}

NodoAVL* insertarAVL(NodoAVL* nodo, const string& fecha, const Venta& venta) {
    if (!nodo) return new NodoAVL{fecha, {venta}, nullptr, nullptr, 1};

    if (fecha < nodo->fecha)
        nodo->izq = insertarAVL(nodo->izq, fecha, venta);
    else if (fecha > nodo->fecha)
        nodo->der = insertarAVL(nodo->der, fecha, venta);
    else {
        nodo->ventas.push_back(venta);
        return nodo;
    }

    actualizarAltura(nodo);
    int balanceFactor = balance(nodo);

    if (balanceFactor > 1 && fecha < nodo->izq->fecha)
        return rotarDerecha(nodo);
    if (balanceFactor < -1 && fecha > nodo->der->fecha)
        return rotarIzquierda(nodo);
    if (balanceFactor > 1 && fecha > nodo->izq->fecha) {
        nodo->izq = rotarIzquierda(nodo->izq);
        return rotarDerecha(nodo);
    }
    if (balanceFactor < -1 && fecha < nodo->der->fecha) {
        nodo->der = rotarDerecha(nodo->der);
        return rotarIzquierda(nodo);
    }

    return nodo;
}

// Recorrido por rango 
void listarVentasPorRango(NodoAVL* nodo, const string& desde, const string& hasta) {
    if (!nodo) return;
    if (desde < nodo->fecha)
        listarVentasPorRango(nodo->izq, desde, hasta);
    if (desde <= nodo->fecha && nodo->fecha <= hasta) {
        for (const Venta& v : nodo->ventas) {
            cout << "ID: " << v.idVenta << " | Fecha: " << v.fecha
                 << " | Producto: " << v.producto << " | Cliente: " << v.cliente
                 << " | Monto: $" << v.montoTotal << endl;
        }
    }
    if (hasta > nodo->fecha)
        listarVentasPorRango(nodo->der, desde, hasta);
}

// Función de validación
bool fechaValida(const string& fecha) {
    if (fecha.length() != 10) return false;
    if (fecha[2] != '-' || fecha[5] != '-') return false;

    for (int i = 0; i < fecha.length(); ++i) {
        if (i == 2 || i == 5) continue;
        if (!isdigit(fecha[i])) return false;
    }

    int dia = stoi(fecha.substr(0, 2));
    int mes = stoi(fecha.substr(3, 2));
    int anio = stoi(fecha.substr(6, 4));

    if (dia < 1 || dia > 31 || mes < 1 || mes > 12 || anio < 1900 || anio > 2100)
        return false;

    return true;
}


// Tabla hash: país → árbol AVL 
unordered_map<string, NodoAVL*> ventasPorPais;

// Lee el archivo CSV 
void cargarCSV(const string& nombreArchivo) {
    ifstream archivo(nombreArchivo);
    if (!archivo.is_open()) {
        cerr << "Error al abrir el archivo: " << nombreArchivo << endl;
        return;
    }

    string linea;
    getline(archivo, linea); // Saltar encabezado

    while (getline(archivo, linea)) {
        stringstream ss(linea);
        string campo;
        Venta v;

        getline(ss, v.idVenta, ',');
        getline(ss, campo, ','); v.fecha = convertirFechaOrdenable(campo);
        string pais;
        getline(ss, pais, ',');
        getline(ss, v.ciudad, ',');
        getline(ss, v.cliente, ',');
        getline(ss, v.producto, ',');
        getline(ss, v.categoria, ',');
        getline(ss, campo, ','); v.cantidad = stoi(campo);
        getline(ss, campo, ','); v.precioUnitario = stof(campo);
        getline(ss, campo, ','); v.montoTotal = stof(campo);
        getline(ss, v.medioEnvio, ',');
        getline(ss, v.estadoEnvio);

        ventasPorPais[pais] = insertarAVL(ventasPorPais[pais], v.fecha, v);
    }

    archivo.close();
}

int main() {
    cargarCSV("ventas_sudamerica(1).csv");

    string paisUsuario, fechaDesde, fechaHasta;
    cout << "\nIngrese el pais: ";
getline(cin, paisUsuario);
// Verifica pais
while (ventasPorPais.find(paisUsuario) == ventasPorPais.end()) {
    cout << "No hay registros para ese pais. Ingrese nuevamente: ";
    getline(cin, paisUsuario);
}

    cout << "Ingrese la fecha desde (DD-MM-AAAA): ";
    getline(cin, fechaDesde);
    while (!fechaValida(fechaDesde)) {
        cout << "Fecha invalida. Ingrese nuevamente (DD-MM-AAAA): ";
        getline(cin, fechaDesde);
    }

    cout << "Ingrese la fecha hasta (DD-MM-AAAA): ";
    getline(cin, fechaHasta);
    while (!fechaValida(fechaHasta)) {
        cout << "Fecha invalida. Ingrese nuevamente (DD-MM-AAAA): ";
        getline(cin, fechaHasta);
    }

    string desdeOrdenable = convertirFechaOrdenable(fechaDesde);
    string hastaOrdenable = convertirFechaOrdenable(fechaHasta);

    if (ventasPorPais.find(paisUsuario) == ventasPorPais.end()) {
        cout << "No hay registros para ese pais.\n";
        return 0;
    }

    cout << "\nVentas en " << paisUsuario << " del " << fechaDesde << " al " << fechaHasta << ":\n";
    listarVentasPorRango(ventasPorPais[paisUsuario], desdeOrdenable, hastaOrdenable);

    return 0;
}

