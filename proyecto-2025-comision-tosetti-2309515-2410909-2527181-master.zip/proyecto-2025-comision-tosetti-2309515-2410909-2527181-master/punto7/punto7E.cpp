//PRODUCTOS VENDIDOS EN PROMEDIO POR DEBAJO Y POR ENCIMA DE UN MONTO TOTAL ESPECIFICADO POR EL USUARIO (UMBRAL) Y POR PAÍS.

#include <iostream>
#include <fstream>
#include <sstream>
#include <unordered_map>
#include <vector>
#include <string>
#include <functional>

using namespace std;

// Alias de estructuras
using ProductoData = pair<int, float>;
using HashProductos = unordered_map<string, ProductoData>;
using HashPaises = unordered_map<string, HashProductos>;

// Función para dividir una línea CSV
vector<string> dividirLineaCSV(const string& linea) {
    vector<string> resultado;
    stringstream ss(linea);
    string campo;

    while (getline(ss, campo, ',')) {
        resultado.push_back(campo);
    }

    return resultado;
}

// Leer archivo CSV y llenar la estructura de datos
void cargarDatosDesdeCSV(const string& nombreArchivo, HashPaises& datos) {
    ifstream archivo(nombreArchivo);
    if (!archivo.is_open()) {
        cerr << "No se pudo abrir el archivo: " << nombreArchivo << endl;
        return;
    }

    string linea;
    getline(archivo, linea); // saltar encabezado

    while (getline(archivo, linea)) {
        vector<string> campos = dividirLineaCSV(linea);
        if (campos.size() < 11) continue; // verificar línea válida

        string pais = campos[2];
        string producto = campos[5];
        int cantidad = stoi(campos[7]);
        float monto = stof(campos[9]);

        datos[pais][producto].first += cantidad;
        datos[pais][producto].second += monto;
    }

    archivo.close();
}

// Mostrar productos filtrados por promedio y umbral
void mostrarProductosFiltrados(
    const HashPaises& datos,
    const string& paisUsuario,
    float umbral,
    const string& condicion
) {
    function<bool(float, float)> comparar;
    comparar = (condicion == "menor") ?
        [](float a, float b) { return a < b; } :
        [](float a, float b) { return a > b; };

    auto it = datos.find(paisUsuario);
    if (it == datos.end()) {
        cout << "Pais no encontrado." << endl;
        return;
    }

    vector<pair<string, float>> productosFiltrados;

    for (const auto& [producto, info] : it->second) {
        int cantidad = info.first;
        float monto = info.second;

        if (cantidad > 0) {
            float promedio = monto / cantidad;
            if (comparar(promedio, umbral)) {
                productosFiltrados.push_back({producto, promedio});
            }
        }
    }

    if (productosFiltrados.empty()) {
        cout << "No se encontraron productos con promedio " << condicion
             << " al umbral de $" << umbral << " en " << paisUsuario << "." << endl;
    } else {
        cout << "Productos con promedio " << condicion << " al umbral de $" << umbral
             << " en " << paisUsuario << ":" << endl;
        for (const auto& [producto, promedio] : productosFiltrados) {
            cout << " - " << producto << " (Promedio: $" << promedio << ")" << endl;
        }
    }
}

int main() {
    HashPaises datos;
    string archivo = "ventas_sudamerica(1).csv";

    cargarDatosDesdeCSV(archivo, datos);

    string pais, condicion;
    float umbral;

    cout << "\n=== FILTRAR PRODUCTOS POR PROMEDIO Y PAIS ===\n";

    //Validar país
    while (true) {
        cout << "Ingrese el nombre del pais: ";
        getline(cin, pais);

        if (datos.find(pais) != datos.end()) break;
        cout << "Pais no encontrado. Intente nuevamente." << endl;
    }

    //Validar umbral
    string entrada;
    while (true) {
        cout << "Ingrese el umbral ($): ";
        getline(cin, entrada);

        try {
            umbral = stof(entrada);
            if (umbral < 0) throw invalid_argument("Negativo");
            break;
        } catch (...) {
            cout << "Ingrese un numero valido mayor o igual a cero." << endl;
        }
    }

    // Validar condición: mayor o menor
    while (true) {
        cout << "Desea ver productos con promedio mayor o menor al umbral? ";
        getline(cin, condicion);

        // convertir a minúsculas
        for (auto& c : condicion) c = tolower(c);

        if (condicion == "mayor" || condicion == "menor") break;

        cout << "Condicion invalida. Ingrese 'mayor' o 'menor'." << endl;
    }

    // Mostrar productos filtrados
    mostrarProductosFiltrados(datos, pais, umbral, condicion);
    return 0;
}

