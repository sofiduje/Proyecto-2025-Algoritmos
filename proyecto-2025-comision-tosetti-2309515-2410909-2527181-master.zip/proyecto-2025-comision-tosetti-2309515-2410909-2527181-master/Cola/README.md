# Colas en C++

Una COLA es una colección ordenada de elementos
de la que se pueden borrar elementos en un extremo
(FRENTE de la cola) o insertarlos en el otro (FINAL de la cola).

## Clase

### Metodos

Constructor()
Destructor()

esVacia()
encolar( dato )
desencolar()
